package SI_lab2_161241;

public class SILab2Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
